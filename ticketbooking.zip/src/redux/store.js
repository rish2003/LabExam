import { configureStore, createSlice } from '@reduxjs/toolkit';

const bookingSlice = createSlice({
  name: 'booking',
  initialState: { selectedTicket: null },
  reducers: {
    setTicket(state, action) {
      state.selectedTicket = action.payload;
    },
  },
});

export const { setTicket } = bookingSlice.actions;

const store = configureStore({
  reducer: { booking: bookingSlice.reducer },
});

export default store;
