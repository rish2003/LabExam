// import React from 'react';
import { useDispatch,useSelector } from 'react-redux';
import Header from './components/Header';
import TicketList from './components/TicketList';
import BookingForm from './components/Bookingform';
import BookingSummary from './components/BookingSummary';
import Footer from './components/Footer';
import { setTicket } from './redux/store';

const App = () => {
  const dispatch = useDispatch();

  const handleSelectTicket = (ticket) => {
    dispatch(setTicket(ticket));
  };

  const handleBookingSubmit = (data) => {
    console.log('Booking Data:', data);
    alert('Booking confirmed!');
  };

  return (
    <div>
      <Header />
      <TicketList onSelectTicket={handleSelectTicket} />
      <BookingSummary />
      <BookingForm
        selectedTicket={useSelector((state) => state.booking.selectedTicket)}
        onSubmit={handleBookingSubmit}
      />
      <Footer />
    </div>
  );
};

export default App;
