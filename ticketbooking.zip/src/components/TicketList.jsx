import { useEffect, useState } from 'react';
import './TicketList.css';

const TicketList = ({ onSelectTicket }) => {
  const [tickets, setTickets] = useState([]);

  useEffect(() => {
    fetch('http://localhost:3001/tickets')
      .then((response) => response.json())
      .then((data) => setTickets(data))
      .catch((err) => console.error(err));
  }, []);

  return (
    <div className="ticket-list">
      <h2>Available Tickets</h2>
      <ul>
        {tickets.map((ticket) => (
          <li key={ticket.id}>
            <span>{ticket.name} - ${ticket.price}</span>
            <button onClick={() => onSelectTicket(ticket)}>Book Now</button>
          </li>
        ))}
      </ul>
    </div>
  );
};

export default TicketList;
