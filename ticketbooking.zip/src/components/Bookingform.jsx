import { useState } from 'react';
import './BookingForm.css';

const BookingForm = ({ selectedTicket, onSubmit }) => {
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');

  const handleSubmit = (e) => {
    e.preventDefault();
    onSubmit({ name, email, ticket: selectedTicket });
  };

  return (
    <form onSubmit={handleSubmit}>
      <h2>Book Your Ticket</h2>
      <label>
        Name:
        <input
          type="text"
          value={name}
          onChange={(e) => setName(e.target.value)}
          required
        />
      </label>
      <label>
        Email:
        <input
          type="email"
          value={email}
          onChange={(e) => setEmail(e.target.value)}
          required
        />
      </label>
      <button type="submit">Confirm Booking</button>
    </form>
  );
};

export default BookingForm;
