import { useSelector } from 'react-redux';
import './BookingSummary.css';

const BookingSummary = () => {
  const selectedTicket = useSelector((state) => state.booking.selectedTicket);

  if (!selectedTicket) return null;

  return (
    <div className="booking-summary">
      <h2>Booking Summary</h2>
      <p>
        Ticket: <span>{selectedTicket.name}</span>
      </p>
      <p>
        Price: <span>${selectedTicket.price}</span>
      </p>
    </div>
  );
};

export default BookingSummary;
