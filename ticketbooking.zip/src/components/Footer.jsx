const Footer = () => <footer>© 2024 Ticket Booking App</footer>;

export default Footer;
