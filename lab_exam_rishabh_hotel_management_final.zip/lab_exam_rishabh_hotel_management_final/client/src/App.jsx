import { Provider } from "react-redux";
import store from "./redux/store.js";
import PatientList from "./components/PatientList";
import AddPatientForm from "./components/AddPatientForm";
import AddDoctorForm from "./components/AddDoctorForm";
import DoctorList from "./components/DoctorList";
import Footer from "./components/Footer";

function App() {
  return (
    <Provider store={store}>
      <div className="min-h-screen bg-gray-100">
        <header className="bg-green-600 text-yellow-200 text-center py-4">
          <h1 className="text-3xl font-bold">Hospital Management App</h1>
        </header>
        <main className="container mx-auto p-4">
          <AddPatientForm />
          <PatientList />
          <AddDoctorForm />
          <DoctorList />
        </main>
        <Footer />
      </div>
    </Provider>
  );
}

export default App;