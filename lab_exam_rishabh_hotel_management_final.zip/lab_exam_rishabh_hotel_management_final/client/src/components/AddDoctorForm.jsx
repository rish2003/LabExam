import { useState } from "react";
import { useDispatch } from "react-redux";
import { addDoctor, resetDoctors } from "../redux/action";

function AddDoctorForm() {
  const [name, setName] = useState("");
  const [age, setAge] = useState("");
  const [specialization, setSpecialization] = useState("");
  const dispatch = useDispatch();

  const handleSubmit = async (e) => {
    e.preventDefault();
    const response = await fetch("http://localhost:3001/doctors", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ name, age, specialization }),
    });
    if (response.ok) {
      const data = await response.json();
      dispatch(addDoctor(data));
      setName("");
      setAge("");
      setSpecialization("");
    }
  };

  const handleReset = async () => {
    const response = await fetch("http://localhost:3001/doctors", {
      method: "DELETE",
    });
    if (response.ok) {
      dispatch(resetDoctors());
      // Optionally, refresh the doctor list
    }
  };

  return (
    <form
      onSubmit={handleSubmit}
      className="bg-white shadow-md rounded p-4 mb-4"
    >
      <h2 className="text-lg font-bold mb-2">Add Doctor</h2>
      <input
        type="text"
        placeholder="Name"
        value={name}
        onChange={(e) => setName(e.target.value)}
        className="border p-2 w-full mb-2"
      />
      <input
        type="number"
        placeholder="Age"
        value={age}
        onChange={(e) => setAge(e.target.value)}
        className="border p-2 w-full mb-2"
      />
      <input
        type="text"
        placeholder="Specialization"
        value={specialization}
        onChange={(e) => setSpecialization(e.target.value)}
        className="border p-2 w-full mb-2"
      />
      <button
        type="submit"
        className="bg-blue-500 text-white px-4 py-2 rounded hover:bg-blue-700"
      >
        Add Doctor
      </button>
      <button
        type="button"
        onClick={handleReset}
        className="bg-red-500 text-white px-4 py-2 rounded hover:bg-red-700 ml-2"
      >
        Reset
      </button>
    </form>
  );
}

export default AddDoctorForm;
