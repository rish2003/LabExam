import { useEffect, useState } from "react";
import { useSelector } from "react-redux";

function DoctorList() {
  const doctors = useSelector((state) => state.doctors);

  return (
    <div className="bg-white shadow-md rounded p-4 mb-4">
      <h2 className="text-lg font-bold mb-2">Doctor List</h2>
      <ul>
        {doctors.map((doctor) => (
          <li key={doctor.id} className="border-b py-2">
            {doctor.name}, {doctor.age} years old ({doctor.specialization})
          </li>
        ))}
      </ul>
    </div>
  );
}

export default DoctorList;
