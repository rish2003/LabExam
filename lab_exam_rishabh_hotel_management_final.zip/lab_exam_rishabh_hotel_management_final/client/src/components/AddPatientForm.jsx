import { useState } from "react";
import { useDispatch } from "react-redux";
import { addPatient, resetPatients } from "../redux/action";

function AddPatientForm() {
  const [name, setName] = useState("");
  const [age, setAge] = useState("");
  const dispatch = useDispatch();

  const fetchPatients = async () => {
    try {
      const response = await fetch("http://localhost:3001/patients");
      const data = await response.json();
      data.forEach((patient) => dispatch(addPatient(patient)));
    } catch (error) {
      console.error("Failed to fetch patients:", error);
    }
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    const response = await fetch("http://localhost:3001/patients", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ name, age }),
    });
    if (response.ok) {
      const data = await response.json();
      dispatch(addPatient(data));
      setName("");
      setAge("");
      fetchPatients();
    }
  };

  const handleReset = async () => {
    const response = await fetch("http://localhost:3001/patients", {
      method: "DELETE",
    });
    if (response.ok) {
      dispatch(resetPatients());
      fetchPatients(); // Refresh the patients list
    }
  };

  return (
    <form
      onSubmit={handleSubmit}
      className="bg-white shadow-md rounded p-4 mb-4"
    >
      <h2 className="text-lg font-bold mb-2">Add Patient</h2>
      <input
        type="text"
        placeholder="Name"
        value={name}
        onChange={(e) => setName(e.target.value)}
        className="border p-2 w-full mb-2"
      />
      <input
        type="number"
        placeholder="Age"
        value={age}
        onChange={(e) => setAge(e.target.value)}
        className="border p-2 w-full mb-2"
      />
      <button
        type="submit"
        className="bg-blue-500 text-white px-4 py-2 rounded hover:bg-blue-700"
      >
        Add Patient
      </button>
      <button
        type="button"
        onClick={handleReset}
        className="bg-red-500 text-white px-4 py-2 rounded hover:bg-red-700 ml-2"
      >
        Reset
      </button>
    </form>
  );
}

export default AddPatientForm;
