import { useEffect, useState } from "react";

function PatientList() {
  const [patients, setPatients] = useState([]);

  useEffect(() => {
    const fetchPatients = async () => {
      const response = await fetch("http://localhost:3001/patients");
      const data = await response.json();
      setPatients(data);
    };
    fetchPatients();
  }, [patients]);

  return (
    <div className="bg-white shadow-md rounded p-4 mb-4">
      <h2 className="text-lg font-bold mb-2">Patient List</h2>
      <ul>
        {patients.map((patient) => (
          <li key={patient.id} className="border-b py-2">
            {patient.name}, {patient.age} years old
          </li>
        ))}
      </ul>
    </div>
  );
}

export default PatientList;
