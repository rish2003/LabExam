import { ADD_PATIENT, RESET_PATIENTS } from './action.js';
import { ADD_DOCTOR, RESET_DOCTORS } from './action.js';

const initialPatientState = [];
const initialDoctorState = [];

export const patientReducer = (state = initialState, action) => {
    switch (action.type) {
        case ADD_PATIENT:
            return {
                ...state,
                patients: [...state.patients, action.payload],
            };
        case RESET_PATIENTS:
            return initialState;
        // other cases
        default:
            return state;
    }
};

export const doctorReducer = (state = initialDoctorState, action) => {
    switch (action.type) {
        case ADD_DOCTOR:
            return [...state, action.payload];
        case RESET_DOCTORS:
            return initialDoctorState;
        default:
            return state;
    }
};

const initialState = {
    patients: [],
    // other initial state
};

export default patientReducer;