// Action types
export const ADD_PATIENT = 'ADD_PATIENT';
export const ADD_DOCTOR = 'ADD_DOCTOR';
export const RESET_DOCTORS = 'RESET_DOCTORS';

// Action creators
export const addPatient = (patient) => ({
    type: ADD_PATIENT,
    payload: patient,
});

export const addDoctor = (doctor) => ({
    type: ADD_DOCTOR,
    payload: doctor,
});

export const RESET_PATIENTS = 'RESET_PATIENTS';

export const resetPatients = () => ({
  type: RESET_PATIENTS,
});

export const resetDoctors = () => ({
  type: RESET_DOCTORS,
});