import { createStore, combineReducers } from 'redux';
import { patientReducer, doctorReducer } from './reducer.js';

const rootReducer = combineReducers({
    patients: patientReducer,
    doctors: doctorReducer,
});

const store = createStore(rootReducer);

export default store;
