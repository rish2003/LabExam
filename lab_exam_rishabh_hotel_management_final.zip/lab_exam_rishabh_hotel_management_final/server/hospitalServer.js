// server.js
const express = require('express');
const bodyParser = require('body-parser');
const cors = require('cors'); // Import cors

const app = express();
const port = 3001;
app.use(cors());
app.use(bodyParser.json());

// In-memory storage for patients (replace this with a database in a real-world application)
const patients = [];
const doctors = [];

app.post('/patients', (req, res) => {
  console.log('Received Patients Data:', req.body);
  const { name, age } = req.body;

  if (!name || !age) {
    return res.status(400).json({ error: 'Name and age are required' });
  }

  const newPatient = { id: patients.length + 1, name, age };
  patients.push(newPatient);

  res.json(newPatient);
});

app.post('/doctors', (req, res) => {
  console.log('Received doctor data:', req.body); // Add this line for debugging

  const { name, age, specialization } = req.body;

  if (!name || !age || !specialization) {
    return res.status(400).json({ error: 'Name, age and spec are required' });
  }

  const newDoctor = { id: doctors.length + 1, name, age, specialization };
  doctors.push(newDoctor);

  res.json(newDoctor);
});

app.get('/patients', (req, res) => {
  res.json(patients);
});

app.get('/doctors', (req, res) => {
  res.json(doctors);
});

app.delete('/patients', (req, res) => {
  patients.length = 0;
  res.json({ message: 'All patients have been reset' });
});

app.delete('/doctors', (req, res) => {
  doctors.length = 0;
  res.json({ message: 'All doctors have been reset' });
});

app.listen(port, () => {
  console.log(`Server is running on http://localhost:${port}`);
});