import React, { useState, useEffect } from "react";
import { useDispatch, useSelector } from "react-redux";
import { setHotels, setSelectedHotel } from "./redux/hotelSlice";
import HotelList from "./components/HotelList";
import HotelDetails from "./components/HotelDetails";
import BookingForm from "./components/BookingForm";
import SearchForm from "./components/SearchForm";
import Confirmation from "./components/Confirmation";

const App = () => {
  const [bookingDetails, setBookingDetails] = useState([]);
  const [showBookings, setShowBookings] = useState(false); // New state to toggle bookings visibility
  const dispatch = useDispatch();
  const selectedHotel = useSelector((state) => state.hotels.selectedHotel); // Getting the selected hotel from the Redux store

  useEffect(() => {
    // Fetch hotel data and populate state
    fetch("https://jsonplaceholder.typicode.com/posts")
      .then((response) => response.json())
      .then((data) =>
        dispatch(
          setHotels(
            data.slice(0, 5).map((item) => ({
              id: item.id,
              name: item.title,
              description: item.body,
            }))
          )
        )
      );
  }, [dispatch]);

  const handleBooking = (details) => {
    setBookingDetails((prevBookings) => [...prevBookings, details]);
  };

  const handleCancelBooking = (bookingId) => {
    setBookingDetails(prevBookings => 
      prevBookings.filter(booking => booking.id !== bookingId)
    );
  };

  const handleHotelSelect = (hotel) => {
    dispatch(setSelectedHotel(hotel)); // Dispatch the selected hotel to the Redux store
  };

  const toggleBookings = () => {
    setShowBookings((prev) => !prev); // Toggle the showBookings state
  };

  return (
    <div>
      <SearchForm onSearch={(term) => console.log(`Searching for: ${term}`)} />
      <HotelList onSelect={handleHotelSelect} />
      <HotelDetails />
      <BookingForm onSubmit={handleBooking} selectedHotel={selectedHotel} />
      <div className="flex justify-center my-6">
        <button 
          onClick={toggleBookings}
          className="bg-gradient-to-r from-indigo-500 to-purple-500 text-white font-bold py-3 px-8 rounded-full shadow-lg hover:from-indigo-600 hover:to-purple-600 transition duration-300 ease-in-out transform hover:-translate-y-1 hover:shadow-xl flex items-center space-x-2"
        >
          <span>{showBookings ? "Hide Bookings" : "Show All Bookings"}</span>
        </button>
      </div>
      {showBookings && (
        <Confirmation 
          bookingDetails={bookingDetails} 
          onCancelBooking={handleCancelBooking}
        />
      )}
    </div>
  );
};

export default App;
