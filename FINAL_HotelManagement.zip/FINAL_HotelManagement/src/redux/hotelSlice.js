import { createSlice } from "@reduxjs/toolkit";

const initialState = {
  list: [], // Initialize as an empty array
  selectedHotel: null,
};

const hotelSlice = createSlice({
  name: "hotels",
  initialState,
  reducers: {
    setHotels: (state, action) => {
      state.list = action.payload; // Update the list of hotels in Redux state
    },
    setSelectedHotel: (state, action) => {
      state.selectedHotel = action.payload; // Store the selected hotel in Redux state
    },
    cancelBooking: (state, action) => {
      // Remove the booking with the specific ID from the list
      state.list = state.list.filter(booking => booking.id !== action.payload);
    },
  },
});

export const { setHotels, setSelectedHotel, cancelBooking } = hotelSlice.actions;

export default hotelSlice.reducer;
