import React from "react";
import { useDispatch, useSelector } from "react-redux";
import { setSelectedHotel } from "../redux/hotelSlice";

const HotelList = () => {
  const dispatch = useDispatch();
  const hotels = useSelector((state) => state.hotels.list);

  const handleSelect = (hotel) => {
    dispatch(setSelectedHotel(hotel));
  };

  if (!Array.isArray(hotels) || hotels.length === 0) {
    return (
      <p className="text-center text-gray-600 text-xl mt-8">No hotels available.</p>
    );
  }

  return (
    <div className="max-w-6xl mx-auto p-6">
      <h2 className="text-3xl font-bold text-center text-indigo-600 mb-8">
        Available Hotels
      </h2>
      <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
        {hotels.map((hotel) => (
          <div 
            key={hotel.id} 
            className="bg-white rounded-xl shadow-lg overflow-hidden transform transition duration-500 hover:scale-105"
          >
            <div className="p-6">
              <h3 className="text-xl font-semibold text-gray-800 mb-4">
                {hotel.name}
              </h3>
              <button
                onClick={() => handleSelect(hotel)}
                className="w-full bg-gradient-to-r from-purple-500 to-indigo-500 text-white font-medium py-2 px-4 rounded-lg hover:from-purple-600 hover:to-indigo-600 transition duration-300"
              >
                View Details
              </button>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

export default HotelList;
