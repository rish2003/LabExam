import React from "react";
import { useDispatch } from "react-redux";
import { cancelBooking } from "../redux/hotelSlice";

const Confirmation = ({ bookingDetails, onCancelBooking }) => {
  const dispatch = useDispatch();

  const handleCancelBooking = (bookingId) => {
    dispatch(cancelBooking(bookingId));
    onCancelBooking(bookingId); // Call the passed function to update local state
  };

  return (
    <div className="max-w-4xl mx-auto p-6">
      <h2 className="text-3xl font-bold text-center text-purple-600 mb-8">
        Booking Confirmations
      </h2>
      <div className="grid gap-6 md:grid-cols-2">
        {bookingDetails.map((booking, index) => (
          <div 
            key={index}
            className="bg-white rounded-xl shadow-lg p-6 transform transition duration-500 hover:scale-105"
          >
            <h3 className="text-xl font-semibold text-indigo-600 mb-4">
              {booking.hotel}
            </h3>
            <div className="space-y-2 text-gray-600">
              <p className="flex items-center">
                <span className="font-medium mr-2">Guest:</span> 
                {booking.name}
              </p>
              <p className="flex items-center">
                <span className="font-medium mr-2">Check-in:</span> 
                {booking.date}
              </p>
              <p className="flex items-center">
                <span className="font-medium mr-2">Guests:</span> 
                {booking.guests}
              </p>
            </div>
            <button
              onClick={() => handleCancelBooking(booking.id)}
              className="mt-4 w-full bg-gradient-to-r from-red-500 to-pink-500 text-white font-medium py-2 px-4 rounded-lg hover:from-red-600 hover:to-pink-600 transition duration-300"
            >
              Cancel Booking
            </button>
          </div>
        ))}
      </div>
    </div>
  );
};

export default Confirmation;