import React from "react";
import { useSelector } from "react-redux";

const HotelDetails = () => {
  const selectedHotel = useSelector((state) => state.hotels.selectedHotel);

  if (!selectedHotel) {
    return (
      <p className="text-center text-gray-600 text-xl mt-8">
        Select a hotel to view details.
      </p>
    );
  }

  return (
    <div className="max-w-2xl mx-auto bg-white rounded-xl shadow-lg overflow-hidden m-6">
      <div className="p-8">
        <h2 className="text-3xl font-bold text-indigo-600 mb-6">
          Hotel Details
        </h2>
        <div className="space-y-4">
          <div className="bg-gradient-to-r from-purple-50 to-indigo-50 p-4 rounded-lg">
            <h3 className="text-xl font-semibold text-gray-800 mb-2">
              {selectedHotel.name}
            </h3>
            <p className="text-gray-600 leading-relaxed">
              {selectedHotel.description}
            </p>
          </div>
        </div>
      </div>
    </div>
  );
};

export default HotelDetails;
