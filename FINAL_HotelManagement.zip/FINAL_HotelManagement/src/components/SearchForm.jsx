import React from "react";

const SearchForm = ({ onSearch }) => {
  const handleSearch = (e) => {
    e.preventDefault();
    const searchTerm = e.target.elements.query.value;
    onSearch(searchTerm);
  };

  return (
    <div className="max-w-2xl mx-auto p-6">
      <form onSubmit={handleSearch} className="flex flex-col items-center space-y-4">
        <h2 className="text-3xl font-bold text-indigo-600">Search Hotels</h2>
        <div className="w-full max-w-md relative">
          <input 
            type="text" 
            name="query" 
            placeholder="Search hotels..." 
            className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-purple-500 focus:border-purple-500 pl-10"
          />
          <button 
            type="submit"
            className="absolute right-2 top-2 bg-gradient-to-r from-purple-500 to-indigo-500 text-white px-4 py-1 rounded-lg hover:from-purple-600 hover:to-indigo-600 transition duration-300"
          >
            Search
          </button>
        </div>
      </form>
    </div>
  );
};

export default SearchForm;
