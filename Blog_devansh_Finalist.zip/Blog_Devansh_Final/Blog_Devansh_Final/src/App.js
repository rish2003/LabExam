import React, { useEffect } from "react";
import { useDispatch, useSelector } from "react-redux";
import { setApiPosts, addUserPost } from "./redux/actions";
import PostList from "./components/PostList";
import PostDetails from "./components/PostDetails";
import NewPostForm from "./components/NewPostForm"; // Import the new post form
import EditPostForm from "./components/EditPostForm"; // Import the edit form
import Footer from "./components/Footer";

const App = () => {
  const dispatch = useDispatch();
  const posts = useSelector((state) => state.apiPosts); // Get posts from the Redux store

  useEffect(() => {
    fetch("https://jsonplaceholder.typicode.com/posts")
      .then((response) => response.json())
      .then((data) => dispatch(setApiPosts(data.slice(0, 5))));
  }, [dispatch]);

  const handleAddNewPost = (newPost) => {
    // Simulating adding a new post with an incremented ID
    const post = {
      id: posts.length + 1, // Generate new ID (for simulation)
      title: newPost.title,
      body: newPost.body,
    };

    dispatch(addUserPost(post)); // Add new post to user posts
    dispatch(setApiPosts([...posts, post])); // Update the API posts if needed
  };

  return (
    <div>
      <h1>React Blog App</h1>
      <NewPostForm handleAddNewPost={handleAddNewPost} /> {/* Render New Post form */}
      <PostList posts={posts} />
      <EditPostForm />
      <PostDetails />
      <Footer />
    </div>
  );
};

export default App;
