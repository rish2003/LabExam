export const setApiPosts = (posts) => ({
  type: "SET_API_POSTS",
  payload: posts,
});

export const addUserPost = (post) => ({
  type: "ADD_USER_POST",
  payload: post,
});

// Add the missing setPost action
export const setPost = (post) => ({
  type: "SET_POST",
  payload: post,
});

export const updatePost = (post) => ({
  type: "UPDATE_POST",
  payload: post,
});

export const deletePost = (postId) => ({
  type: "DELETE_POST",
  payload: postId,
});

