const initialState = {
  apiPosts: [],
  userPosts: [],
  selectedPost: null,
};

const postReducer = (state = initialState, action) => {
  switch (action.type) {
    case "SET_API_POSTS":
      return { ...state, apiPosts: action.payload };

    case "ADD_USER_POST":
      return { ...state, userPosts: [...state.userPosts, action.payload] };

    case "SET_POST":
      return { ...state, selectedPost: action.payload };

    case "UPDATE_POST":
      const updatedPosts = state.apiPosts.map((post) =>
        post.id === action.payload.id ? action.payload : post
      );
      return { ...state, apiPosts: updatedPosts, selectedPost: null };

    case "DELETE_POST":
      const filteredPosts = state.apiPosts.filter(
        (post) => post.id !== action.payload
      );
      return { ...state, apiPosts: filteredPosts, selectedPost: null };

    default:
      return state;
  }
};

export default postReducer;
