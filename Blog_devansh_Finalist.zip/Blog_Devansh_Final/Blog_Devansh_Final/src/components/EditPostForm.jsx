import React, { useState, useEffect } from "react";
import { useSelector, useDispatch } from "react-redux";
import { updatePost, deletePost } from "../redux/actions";

const EditPostForm = () => {
  const selectedPost = useSelector((state) => state.selectedPost);
  const [title, setTitle] = useState(selectedPost?.title || "");
  const [body, setBody] = useState(selectedPost?.body || "");
  const dispatch = useDispatch();

  useEffect(() => {
    if (selectedPost) {
      setTitle(selectedPost.title);
      setBody(selectedPost.body);
    }
  }, [selectedPost]);

  const handleSubmit = (e) => {
    e.preventDefault();
    if (!selectedPost) return;
    dispatch(updatePost({ ...selectedPost, title, body }));
    setTitle("");
    setBody("");
  };

  const handleDelete = () => {
    if (!selectedPost) return;
    dispatch(deletePost(selectedPost.id));
    setTitle("");
    setBody("");
  };

  if (!selectedPost) return null;

  return (
    <div className="edit-form-container" style={styles.container}>
      <h2 style={styles.heading}>Edit Post</h2>
      <form onSubmit={handleSubmit} style={styles.form}>
        <div style={styles.inputGroup}>
          <label style={styles.label}>Title</label>
          <input
            type="text"
            value={title}
            onChange={(e) => setTitle(e.target.value)}
            style={styles.input}
          />
        </div>
        <div style={styles.inputGroup}>
          <label style={styles.label}>Content</label>
          <textarea
            value={body}
            onChange={(e) => setBody(e.target.value)}
            style={styles.textarea}
            rows="6"
          />
        </div>
        <div style={styles.buttonGroup}>
          <button type="submit" style={styles.button}>
            Update Post
          </button>
          <button
            type="button"
            style={{ ...styles.button, backgroundColor: "#e53e3e" }}
            onClick={handleDelete}
          >
            Delete Post
          </button>
        </div>
      </form>
    </div>
  );
};

const styles = {
  container: {
    backgroundColor: "#ffffff",
    borderRadius: "8px",
    padding: "2rem",
    boxShadow: "0 4px 6px rgba(0, 0, 0, 0.1)",
    maxWidth: "600px",
    margin: "2rem auto",
  },
  heading: {
    color: "#2c3e50",
    marginBottom: "1.5rem",
    fontSize: "1.8rem",
    fontWeight: "600",
  },
  form: {
    display: "flex",
    flexDirection: "column",
    gap: "1.5rem",
  },
  inputGroup: {
    display: "flex",
    flexDirection: "column",
    gap: "0.5rem",
  },
  label: {
    fontSize: "1rem",
    color: "#4a5568",
    fontWeight: "500",
  },
  input: {
    padding: "0.75rem",
    borderRadius: "4px",
    border: "1px solid #e2e8f0",
    fontSize: "1rem",
    transition: "border-color 0.2s",
    outline: "none",
  },
  textarea: {
    padding: "0.75rem",
    borderRadius: "4px",
    border: "1px solid #e2e8f0",
    fontSize: "1rem",
    resize: "vertical",
    outline: "none",
  },
  buttonGroup: {
    display: "flex",
    gap: "1rem",
    justifyContent: "space-between",
  },
  button: {
    backgroundColor: "#4299e1",
    color: "white",
    padding: "0.75rem 1.5rem",
    borderRadius: "4px",
    border: "none",
    fontSize: "1rem",
    fontWeight: "500",
    cursor: "pointer",
    transition: "background-color 0.2s",
  },
};

export default EditPostForm;
