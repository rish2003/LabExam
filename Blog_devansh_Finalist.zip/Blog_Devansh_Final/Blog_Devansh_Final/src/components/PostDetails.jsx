import React from "react";
import { useSelector } from "react-redux";

const PostDetails = () => {
  const selectedPost = useSelector((state) => state.selectedPost);

  if (!selectedPost) {
    return (
      <div style={styles.emptyState}>
        <p>Select a post to view details</p>
      </div>
    );
  }

  return (
    <div style={styles.container}>
      <h2 style={styles.title}>{selectedPost.title}</h2>
      <div style={styles.content}>
        <p style={styles.body}>{selectedPost.body}</p>
      </div>
    </div>
  );
};

const styles = {
  container: {
    backgroundColor: '#ffffff',
    borderRadius: '8px',
    padding: '2rem',
    boxShadow: '0 4px 6px rgba(0, 0, 0, 0.1)',
    maxWidth: '800px',
    margin: '2rem auto',
  },
  title: {
    color: '#2d3748',
    fontSize: '2rem',
    fontWeight: '700',
    marginBottom: '1.5rem',
    borderBottom: '2px solid #e2e8f0',
    paddingBottom: '0.5rem',
  },
  content: {
    padding: '1rem 0',
  },
  body: {
    fontSize: '1.1rem',
    lineHeight: '1.7',
    color: '#4a5568',
  },
  emptyState: {
    textAlign: 'center',
    padding: '3rem',
    color: '#718096',
    fontSize: '1.1rem',
    backgroundColor: '#f7fafc',
    borderRadius: '8px',
    margin: '2rem auto',
    maxWidth: '600px',
  },
};

export default PostDetails;
