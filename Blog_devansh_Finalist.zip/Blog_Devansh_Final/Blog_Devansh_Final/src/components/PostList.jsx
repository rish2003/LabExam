import React from "react";
import { useDispatch } from "react-redux";
import { setPost } from "../redux/actions";

const PostList = ({ posts }) => {
  const dispatch = useDispatch();

  const handleSelectPost = (post) => {
    dispatch(setPost(post));
  };

  return (
    <div style={styles.container}>
      <h2 style={styles.heading}>Post List</h2>
      <div style={styles.grid}>
        {posts.map((post) => (
          <div key={post.id} style={styles.card}>
            <h3 style={styles.cardTitle}>{post.title}</h3>
            <p style={styles.excerpt}>
              {post.body.substring(0, 100)}...
            </p>
            <button
              onClick={() => handleSelectPost(post)}
              style={styles.button}
            >
              Read More
            </button>
          </div>
        ))}
      </div>
    </div>
  );
};

const styles = {
  container: {
    padding: '2rem',
    maxWidth: '1200px',
    margin: '0 auto',
  },
  heading: {
    color: '#2d3748',
    fontSize: '2rem',
    fontWeight: '700',
    marginBottom: '2rem',
    textAlign: 'center',
  },
  grid: {
    display: 'grid',
    gridTemplateColumns: 'repeat(auto-fill, minmax(300px, 1fr))',
    gap: '2rem',
    padding: '1rem',
  },
  card: {
    backgroundColor: '#ffffff',
    borderRadius: '8px',
    padding: '1.5rem',
    boxShadow: '0 4px 6px rgba(0, 0, 0, 0.1)',
    transition: 'transform 0.2s',
    '&:hover': {
      transform: 'translateY(-4px)',
    },
  },
  cardTitle: {
    color: '#2d3748',
    fontSize: '1.25rem',
    fontWeight: '600',
    marginBottom: '1rem',
  },
  excerpt: {
    color: '#4a5568',
    fontSize: '1rem',
    lineHeight: '1.5',
    marginBottom: '1.5rem',
  },
  button: {
    backgroundColor: '#4299e1',
    color: 'white',
    padding: '0.5rem 1rem',
    borderRadius: '4px',
    border: 'none',
    fontSize: '0.875rem',
    fontWeight: '500',
    cursor: 'pointer',
    transition: 'background-color 0.2s',
    '&:hover': {
      backgroundColor: '#3182ce',
    },
  },
};

export default PostList;
